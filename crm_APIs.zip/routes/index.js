exports.userRoute = require("./auth/user");
exports.leadRoute = require("./auth/lead");
exports.generalRoute = require("./auth/general");
exports.siteRoute = require("./auth/website");

